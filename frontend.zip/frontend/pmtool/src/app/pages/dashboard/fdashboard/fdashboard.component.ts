import { Component } from '@angular/core';

@Component({
  selector: 'app-fdashboard',
  templateUrl: './fdashboard.component.html',
  styleUrls: ['./fdashboard.component.scss']
})
export class FdashboardComponent {

}
