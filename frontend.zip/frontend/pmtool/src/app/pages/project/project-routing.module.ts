import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectlistComponent } from './projectlist/projectlist.component';
import { ProjectaddComponent } from './projectadd/projectadd.component';

const routes: Routes = [
  {
    path: 'projectlist',
    component: ProjectlistComponent
},
{
  path: 'projectadd',
  component: ProjectaddComponent
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectRoutingModule { }
