import { Menuitems } from "./menuitems.model";

export const  Menu:Menuitems[] = [ 
    {
        id: 1,
        label: 'Menuitems.Menu.TEXT',
        isTitle: true
    },
    {
        id: 2,
        label: 'Menuitems.DASHBOARDS.TEXT',
        icon: 'bx-home-circle',
        subItems: [
            {
                id: 3,
                label: 'Menuitems.DASHBOARDS.LIST.DEFAULT',
                link: '/dashboard',
                parentId: 2
            },
            {
                id: 4,
                label: 'Menuitems.DASHBOARDS.LIST.SAAS',
                link: '/dashboards/saas',
                parentId: 2
            },
            {
                id: 5,
                label: 'Menuitems.DASHBOARDS.LIST.CRYPTO',
                link: '/dashboards/crypto',
                parentId: 2
            },
            {
                id: 6,
                label: 'Menuitems.DASHBOARDS.LIST.BLOG',
                link: '/dashboards/blog',
                parentId: 2
            },
            {
                id: 7,
                label: 'Menuitems.DASHBOARDS.LIST.JOBS',
                link: '/dashboards/jobs',
                parentId: 2,
            },
        ]
    },
    {
        id: 8,
        isLayout: true
    },
    {
        id: 9,
        label: 'Menuitems.APPS.TEXT',
        isTitle: true
    },
    {
        id: 10,
        label: 'Menuitems.CALENDAR.TEXT',
        icon: 'bx-calendar',
        link: '/calendar',
    },
    {
        id: 11,
        label: 'Menuitems.CHAT.TEXT',
        icon: 'bx-chat',
        link: '/chat',
        
    },
    {
        id: 12,
        label: 'Menuitems.FILEMANAGER.TEXT',
        icon: 'bx-file',
        link: '/filemanager',
    },
    {
        id: 13,
        label: 'Menuitems.ECOMMERCE.TEXT',
        icon: 'bx-store',
        subItems: [
            {
                id: 14,
                label: 'Menuitems.ECOMMERCE.LIST.PRODUCTS',
                link: '/ecommerce/products',
                parentId: 13
            },
            {
                id: 15,
                label: 'Menuitems.ECOMMERCE.LIST.PRODUCTDETAIL',
                link: '/ecommerce/product-detail/1',
                parentId: 13
            },
            {
                id: 16,
                label: 'Menuitems.ECOMMERCE.LIST.ORDERS',
                link: '/ecommerce/orders',
                parentId: 13
            },
            {
                id: 17,
                label: 'Menuitems.ECOMMERCE.LIST.CUSTOMERS',
                link: '/ecommerce/customers',
                parentId: 13
            },
            {
                id: 18,
                label: 'Menuitems.ECOMMERCE.LIST.CART',
                link: '/ecommerce/cart',
                parentId: 13
            },
            {
                id: 19,
                label: 'Menuitems.ECOMMERCE.LIST.CHECKOUT',
                link: '/ecommerce/checkout',
                parentId: 13
            },
            {
                id: 20,
                label: 'Menuitems.ECOMMERCE.LIST.SHOPS',
                link: '/ecommerce/shops',
                parentId: 13
            },
            {
                id: 21,
                label: 'Menuitems.ECOMMERCE.LIST.ADDPRODUCT',
                link: '/ecommerce/add-product',
                parentId: 13
            },
        ]
    },
    {
        id: 22,
        label: 'Menuitems.CRYPTO.TEXT',
        icon: 'bx-bitcoin',
        subItems: [
            {
                id: 23,
                label: 'Menuitems.CRYPTO.LIST.WALLET',
                link: '/crypto/wallet',
                parentId: 22
            },
            {
                id: 24,
                label: 'Menuitems.CRYPTO.LIST.BUY/SELL',
                link: '/crypto/buy-sell',
                parentId: 22
            },
            {
                id: 25,
                label: 'Menuitems.CRYPTO.LIST.EXCHANGE',
                link: '/crypto/exchange',
                parentId: 22
            },
            {
                id: 26,
                label: 'Menuitems.CRYPTO.LIST.LENDING',
                link: '/crypto/lending',
                parentId: 22
            },
            {
                id: 27,
                label: 'Menuitems.CRYPTO.LIST.ORDERS',
                link: '/crypto/orders',
                parentId: 22
            },
            {
                id: 28,
                label: 'Menuitems.CRYPTO.LIST.KYCAPPLICATION',
                link: '/crypto/kyc-application',
                parentId: 22
            },
            {
                id: 29,
                label: 'Menuitems.CRYPTO.LIST.ICOLANDING',
                link: '/crypto-ico-landing',
                parentId: 22
            }
        ]
    },
    {
        id: 30,
        label: 'Menuitems.EMAIL.TEXT',
        icon: 'bx-envelope',
        subItems: [
            {
                id: 31,
                label: 'Menuitems.EMAIL.LIST.INBOX',
                link: '/email/inbox',
                parentId: 30
            },
            {
                id: 32,
                label: 'Menuitems.EMAIL.LIST.READEMAIL',
                link: '/email/read/1',
                parentId: 30
            },
            {
                id: 33,
                label: 'Menuitems.EMAIL.LIST.TEMPLATE.TEXT',
                badge: {
                    variant: 'success',
                    text: 'Menuitems.EMAIL.LIST.TEMPLATE.BADGE',
                },
                parentId: 30,
                subItems: [
                    {
                        id:34,
                        label: 'Menuitems.EMAIL.LIST.TEMPLATE.LIST.BASIC',
                        link: '/email/basic',
                        parentId:30 
                    },
                    {
                        id:35,
                        label: 'Menuitems.EMAIL.LIST.TEMPLATE.LIST.ALERT',
                        link: '/email/alert',
                        parentId:30
                    },
                    {
                        id:36,
                        label: 'Menuitems.EMAIL.LIST.TEMPLATE.LIST.BILLING',
                        link: '/email/billing',
                        parentId:30
                    }
                ]
            }
        ]
    },
    {
        id: 37,
        label: 'Menuitems.INVOICES.TEXT',
        icon: 'bx-receipt',
        subItems: [
            {
                id: 38,
                label: 'Menuitems.INVOICES.LIST.INVOICELIST',
                link: '/invoices/list',
                parentId: 37
            },
            {
                id: 39,
                label: 'Menuitems.INVOICES.LIST.INVOICEDETAIL',
                link: '/invoices/detail',
                parentId: 37
            },
        ]
    },
    {
        id: 40,
        label: 'Menuitems.PROJECTS.TEXT',
        icon: 'bx-briefcase-alt-2',
        subItems: [
            {
                id: 41,
                label: 'Menuitems.PROJECTS.LIST.GRID',
                link: '/projects/grid',
                parentId: 40
            },
            {
                id: 42,
                label: 'Menuitems.PROJECTS.LIST.PROJECTLIST',
                link: '/projects/list',
                parentId: 40
            },
            {
                id: 43,
                label: 'Menuitems.PROJECTS.LIST.OVERVIEW',
                link: '/projects/overview',
                parentId: 40
            },
            {
                id: 44,
                label: 'Menuitems.PROJECTS.LIST.CREATE',
                link: '/projects/create',
                parentId: 40
            }
        ]
    },
    {
        id: 45,
        label: 'Menuitems.TASKS.TEXT',
        icon: 'bx-task',
        subItems: [
            {
                id: 46,
                label: 'Menuitems.TASKS.LIST.TASKLIST',
                link: '/tasks/list',
                parentId: 45
            },
            {
                id: 47,
                label: 'Menuitems.TASKS.LIST.KANBAN',
                link: '/tasks/kanban',
                parentId: 45
            },
            {
                id: 48,
                label: 'Menuitems.TASKS.LIST.CREATETASK',
                link: '/tasks/create',
                parentId: 45
            }
        ]
    },
    {
        id: 49,
        label: 'Menuitems.CONTACTS.TEXT',
        icon: 'bxs-user-detail',
        subItems: [
            {
                id: 50,
                label: 'Menuitems.CONTACTS.LIST.USERGRID',
                link: '/contacts/grid',
                parentId: 49
            },
            {
                id: 51,
                label: 'Menuitems.CONTACTS.LIST.USERLIST',
                link: '/contacts/list',
                parentId: 49
            },
            {
                id: 52,
                label: 'Menuitems.CONTACTS.LIST.PROFILE',
                link: '/contacts/profile',
                parentId: 49
            }
        ]
    },
    {
        id: 53,
        label: 'Menuitems.BLOG.TEXT',
        icon: 'bx-file',
        subItems: [
            {
                id: 54,
                label: 'Menuitems.BLOG.LIST.BLOGLIST',
                link: '/blog/list',
                parentId: 53
            },
            {
                id: 55,
                label: 'Menuitems.BLOG.LIST.BLOGGRID',
                link: '/blog/grid',
                parentId: 53
            },
            {
                id: 56,
                label: 'Menuitems.BLOG.LIST.DETAIL',
                link: '/blog/detail',
                parentId: 53
            },
        ]
    },
    {
        id: 57,
        label: 'Menuitems.JOBS.TEXT',
        icon: 'bx-briefcase-alt',
        subItems: [
            {
                id: 58,
                label: 'Menuitems.JOBS.LIST.JOBLIST',
                link: '/jobs/list',
                parentId: 57
            },
            {
                id: 59,
                label: 'Menuitems.JOBS.LIST.JOBGRID',
                link: '/jobs/grid',
                parentId: 57
            },
            {
                id: 60,
                label: 'Menuitems.JOBS.LIST.APPLYJOB',
                link: '/jobs/apply',
                parentId: 57
            },
            {
                id: 61,
                label: 'Menuitems.JOBS.LIST.JOBDETAILS',
                link: '/jobs/details',
                parentId: 57
            },
            {
                id: 62,
                label: 'Menuitems.JOBS.LIST.JOBCATEGORIES',
                link: '/jobs/categories',
                parentId: 57
            },
            {
                id: 63,
                label: 'Menuitems.JOBS.LIST.CANDIDATE.TEXT',
                badge: {
                    variant: 'success',
                    text: 'Menuitems.EMAIL.LIST.TEMPLATE.BADGE',
                },
                parentId: 57,
                subItems: [
                    {
                        id:64,
                        label: 'Menuitems.JOBS.LIST.CANDIDATE.LIST.LIST',
                        link: '/jobs/candidate-list',
                        parentId:57 
                    },
                    {
                        id:65,
                        label: 'Menuitems.JOBS.LIST.CANDIDATE.LIST.OVERVIEW',
                        link: '/jobs/candidate-overview',
                        parentId:57
                    }
                ]
            }
        ]
    },
    {
        id: 66,
        label: 'Menuitems.PAGES.TEXT',
        isTitle: true
    },
    {
        id: 67,
        label: 'Menuitems.AUTHENTICATION.TEXT',
        icon: 'bx-user-circle',
        subItems: [
            {
                id: 68,
                label: 'Menuitems.AUTHENTICATION.LIST.LOGIN',
                link: '/account/login',
                parentId: 67
            },
            {
                id: 69,
                label: 'Menuitems.AUTHENTICATION.LIST.LOGIN2',
                link: '/account/login-2',
                parentId: 67
            },
            {
                id: 70,
                label: 'Menuitems.AUTHENTICATION.LIST.REGISTER',
                link: '/account/signup',
                parentId: 67
            },
            {
                id: 71,
                label: 'Menuitems.AUTHENTICATION.LIST.REGISTER2',
                link: '/account/signup-2',
                parentId: 67
            },
            {
                id: 72,
                label: 'Menuitems.AUTHENTICATION.LIST.RECOVERPWD',
                link: '/account/reset-password',
                parentId: 67
            },
            {
                id: 73,
                label: 'Menuitems.AUTHENTICATION.LIST.RECOVERPWD2',
                link: '/account/recoverpwd-2',
                parentId: 67
            },
            {
                id: 74,
                label: 'Menuitems.AUTHENTICATION.LIST.LOCKSCREEN',
                link: '/pages/lock-screen-1',
                parentId: 67
            },
            {
                id: 75,
                label: 'Menuitems.AUTHENTICATION.LIST.LOCKSCREEN2',
                link: '/pages/lock-screen-2',
                parentId: 67
            },
            {
                id: 76,
                label: 'Menuitems.AUTHENTICATION.LIST.CONFIRMMAIL',
                link: '/pages/confirm-mail',
                parentId: 67
            },
            {
                id: 77,
                label: 'Menuitems.AUTHENTICATION.LIST.CONFIRMMAIL2',
                link: '/pages/confirm-mail-2',
                parentId: 67
            },
            {
                id: 78,
                label: 'Menuitems.AUTHENTICATION.LIST.EMAILVERIFICATION',
                link: '/pages/email-verification',
                parentId: 67
            },
            {
                id: 79,
                label: 'Menuitems.AUTHENTICATION.LIST.EMAILVERIFICATION2',
                link: '/pages/email-verification-2',
                parentId: 67
            },
            {
                id: 80,
                label: 'Menuitems.AUTHENTICATION.LIST.TWOSTEPVERIFICATION',
                link: '/pages/two-step-verification',
                parentId: 67
            },
            {
                id: 81,
                label: 'Menuitems.AUTHENTICATION.LIST.TWOSTEPVERIFICATION2',
                link: '/pages/two-step-verification-2',
                parentId: 67
            }
        ]
    },
    {
        id: 82,
        label: 'Menuitems.UTILITY.TEXT',
        icon: 'bx-file',
        subItems: [
            {
                id: 83,
                label: 'Menuitems.UTILITY.LIST.STARTER',
                link: '/pages/starter',
                parentId: 82
            },
            {
                id: 84,
                label: 'Menuitems.UTILITY.LIST.MAINTENANCE',
                link: '/pages/maintenance',
                parentId: 82
            },
            {
                id: 85,
                label: 'Coming Soon',
                link: '/pages/coming-soon',
                parentId: 82
            },
            {
                id: 86,
                label: 'Menuitems.UTILITY.LIST.TIMELINE',
                link: '/pages/timeline',
                parentId: 82
            },
            {
                id: 87,
                label: 'Menuitems.UTILITY.LIST.FAQS',
                link: '/pages/faqs',
                parentId: 82
            },
            {
                id: 88,
                label: 'Menuitems.UTILITY.LIST.PRICING',
                link: '/pages/pricing',
                parentId: 82
            },
            {
                id: 89,
                label: 'Menuitems.UTILITY.LIST.ERROR404',
                link: '/pages/404',
                parentId: 82
            },
            {
                id: 90,
                label: 'Menuitems.UTILITY.LIST.ERROR500',
                link: '/pages/500',
                parentId: 82
            },
        ]
    },
    {
        id: 91,
        label: 'Menuitems.COMPONENTS.TEXT',
        isTitle: true
    },
    {
        id: 92,
        label: 'Menuitems.UIELEMENTS.TEXT',
        icon: 'bx-tone',
        subItems: [
            {
                id: 93,
                label: 'Menuitems.UIELEMENTS.LIST.ALERTS',
                link: '/ui/alerts',
                parentId: 92
            },
            {
                id: 94,
                label: 'Menuitems.UIELEMENTS.LIST.BUTTONS',
                link: '/ui/buttons',
                parentId: 92
            },
            {
                id: 95,
                label: 'Menuitems.UIELEMENTS.LIST.CARDS',
                link: '/ui/cards',
                parentId: 92
            },
            {
                id: 96,
                label: 'Menuitems.UIELEMENTS.LIST.CAROUSEL',
                link: '/ui/carousel',
                parentId: 92
            },
            {
                id: 97,
                label: 'Menuitems.UIELEMENTS.LIST.DROPDOWNS',
                link: '/ui/dropdowns',
                parentId: 92
            },
            {
                id: 98,
                label: 'Menuitems.UIELEMENTS.LIST.GRID',
                link: '/ui/grid',
                parentId: 92
            },
            {
                id: 99,
                label: 'Menuitems.UIELEMENTS.LIST.IMAGES',
                link: '/ui/images',
                parentId: 92
            },
            {
                id: 100,
                label: 'Menuitems.UIELEMENTS.LIST.LIGHTBOX',
                link: '/ui/lightbox',
                parentId: 92
            },
            {
                id: 101,
                label: 'Menuitems.UIELEMENTS.LIST.MODALS',
                link: '/ui/modals',
                parentId: 92
            },
            {
                id: 102,
                label: 'Menuitems.UIELEMENTS.LIST.RANGESLIDER',
                link: '/ui/rangeslider',
                parentId: 92
            },
            {
                id: 103,
                label: 'Menuitems.UIELEMENTS.LIST.PROGRESSBAR',
                link: '/ui/progressbar',
                parentId: 92
            },
            {
                id: 104,
                label: 'Menuitems.UIELEMENTS.LIST.PLACEHOLDER',
                link: '/ui/placeholder',
                parentId: 92
            },
            {
                id: 105,
                label: 'Menuitems.UIELEMENTS.LIST.SWEETALERT',
                link: '/ui/sweet-alert',
                parentId: 92
            },
            {
                id: 106,
                label: 'Menuitems.UIELEMENTS.LIST.TABS',
                link: '/ui/tabs-accordions',
                parentId: 92
            },
            {
                id: 107,
                label: 'Menuitems.UIELEMENTS.LIST.TYPOGRAPHY',
                link: '/ui/typography',
                parentId: 92
            },
            {
                id: 108,
                label: 'Menuitems.UIELEMENTS.LIST.TOASTS',
                link: '/ui/toasts',
                parentId: 92
            },
            {
                id: 109,
                label: 'Menuitems.UIELEMENTS.LIST.VIDEO',
                link: '/ui/video',
                parentId: 92
            },
            {
                id: 110,
                label: 'Menuitems.UIELEMENTS.LIST.GENERAL',
                link: '/ui/general',
                parentId: 92
            },
            {
                id: 111,
                label: 'Menuitems.UIELEMENTS.LIST.COLORS',
                link: '/ui/colors',
                parentId: 92
            },
            {
                id: 112,
                label: 'Menuitems.UIELEMENTS.LIST.RATING',
                link: '/ui/rating',
                parentId: 92
            },
            {
                id: 113,
                label: 'Menuitems.UIELEMENTS.LIST.NOTIFICATION',
                link: '/ui/notification',
                parentId: 92
            },
            {
                id: 114,
                label: 'Menuitems.UIELEMENTS.LIST.UTILITIES',
                link: '/ui/utilities',
                parentId: 92
            },
            {
                id: 115,
                label: 'Menuitems.UIELEMENTS.LIST.CROPPER',
                link: '/ui/image-crop',
                parentId: 92
            },
        ]
    },
    {
        id: 116,
        label: 'Menuitems.FORMS.TEXT',
        icon: 'bxs-eraser',
        badge: {
            variant: 'danger',
            text: 'Menuitems.FORMS.BADGE',
        },
        subItems: [
            {
                id: 117,
                label: 'Menuitems.FORMS.LIST.ELEMENTS',
                link: '/form/elements',
                parentId: 116
            },
            {
                id: 118,
                label: 'Menuitems.FORMS.LIST.LAYOUTS',
                link: '/form/layouts',
                parentId: 116
            },
            {
                id: 119,
                label: 'Menuitems.FORMS.LIST.VALIDATION',
                link: '/form/validation',
                parentId: 116
            },
            {
                id: 120,
                label: 'Menuitems.FORMS.LIST.ADVANCED',
                link: '/form/advanced',
                parentId: 116
            },
            {
                id: 121,
                label: 'Menuitems.FORMS.LIST.EDITOR',
                link: '/form/editor',
                parentId: 116
            },
            {
                id: 122,
                label: 'Menuitems.FORMS.LIST.FILEUPLOAD',
                link: '/form/uploads',
                parentId: 116
            },
            {
                id: 123,
                label: 'Menuitems.FORMS.LIST.REPEATER',
                link: '/form/repeater',
                parentId: 116
            },
            {
                id: 124,
                label: 'Menuitems.FORMS.LIST.WIZARD',
                link: '/form/wizard',
                parentId: 116
            },
            {
                id: 125,
                label: 'Menuitems.FORMS.LIST.MASK',
                link: '/form/mask',
                parentId: 116
            }
        ]
    },
    {
        id: 126,
        icon: 'bx-list-ul',
        label: 'Menuitems.TABLES.TEXT',
        subItems: [
            {
                id: 127,
                label: 'Menuitems.TABLES.LIST.BASIC',
                link: '/tables/basic',
                parentId: 126
            },
            {
                id: 128,
                label: 'Menuitems.TABLES.LIST.DataTables',
                link: '/tables/advanced',
                parentId: 126
            }
        ]
    },
    {
        id: 130,
        icon: 'bxs-bar-chart-alt-2',
        label: 'Menuitems.CHARTS.TEXT',
        subItems: [
            {
                id: 131,
                label: 'Menuitems.CHARTS.LIST.APEX',
                link: '/charts/apex',
                parentId: 130
            },
            {
                id: 132,
                label: 'Menuitems.CHARTS.LIST.CHARTJS',
                link: '/charts/chartjs',
                parentId: 131
            },
            {
                id: 133,
                label: 'Menuitems.CHARTS.LIST.CHARTIST',
                link: '/charts/chartist',
                parentId: 131
            },
            {
                id: 134,
                label: 'Menuitems.CHARTS.LIST.ECHART',
                link: '/charts/echart',
                parentId: 131
            }
        ]
    },
    {
        id: 135,
        label: 'Menuitems.ICONS.TEXT',
        icon: 'bx-aperture',
        subItems: [
            {
                id: 136,
                label: 'Menuitems.ICONS.LIST.BOXICONS',
                link: '/icons/boxicons',
                parentId: 135
            },
            {
                id: 137,
                label: 'Menuitems.ICONS.LIST.MATERIALDESIGN',
                link: '/icons/materialdesign',
                parentId: 135
            },
            {
                id: 138,
                label: 'Menuitems.ICONS.LIST.DRIPICONS',
                link: '/icons/dripicons',
                parentId: 135
            },
            {
                id: 139,
                label: 'Menuitems.ICONS.LIST.FONTAWESOME',
                link: '/icons/fontawesome',
                parentId: 135
            },
        ]
    },
    {
        id: 140,
        label: 'Menuitems.MAPS.TEXT',
        icon: 'bx-map',
        subItems: [
            // {
            //     id: 141,
            //     label: 'Menuitems.MAPS.LIST.GOOGLEMAP',
            //     link: '/maps/google',
            //     parentId: 140
            // },
            {
                id: 142,
                label: 'Menuitems.MAPS.LIST.LEAFLETMAP',
                link: '/maps/leaflet',
                parentId: 140
            }
        ]
    },
    {
        id: 143,
        label: 'Menuitems.MULTILEVEL.TEXT',
        icon: 'bx-share-alt',
        subItems: [
            {
                id: 144,
                label: 'Menuitems.MULTILEVEL.LIST.LEVEL1.1',
                parentId: 143
            },
            {
                id: 145,
                label: 'Menuitems.MULTILEVEL.LIST.LEVEL1.2',
                parentId: 143,
                subItems: [
                    {
                        id: 146,
                        label: 'Menuitems.MULTILEVEL.LIST.LEVEL1.LEVEL2.1',
                        parentId: 145,
                    },
                    {
                        id: 147,
                        label: 'Menuitems.MULTILEVEL.LIST.LEVEL1.LEVEL2.2',
                        parentId:145,
                    }
                ]
            },
        ]
    }
];
