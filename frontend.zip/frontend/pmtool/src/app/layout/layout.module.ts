import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerticalComponent } from './vertical/vertical.component';
import { RouterModule } from '@angular/router';
import { TopbarComponent } from './topbar/topbar.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { RsidebarComponent } from './rsidebar/rsidebar.component';
import { TranslateModule } from '@ngx-translate/core';
import { LangService } from '../core/service/lang.service';
// import { SimplebarAngularModule } from 'simplebar-angular';
// import { NgxSimplebarComponent } from 'ngx-simplebar';
import { NgxSimplebarModule } from 'ngx-simplebar';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@NgModule({
  declarations: [
    VerticalComponent,
    TopbarComponent,
    FooterComponent,
    SidebarComponent,
    RsidebarComponent,
    
  ],
  imports: [
    CommonModule,
    RouterModule,
    TranslateModule,
    NgxSimplebarModule,
    BsDropdownModule.forRoot(),
    
  ],
  providers:[LangService]
})
export class LayoutModule { }
