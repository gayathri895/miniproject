import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CarouselModule } from 'ngx-owl-carousel-o';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutComponent } from './layout/layout.component';
import { VerticalComponent } from './layout/vertical/vertical.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { TopbarComponent } from './layout/topbar/topbar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { RsidebarComponent } from './layout/rsidebar/rsidebar.component';
import { TranslateModule } from '@ngx-translate/core';
// import { NgxSimplebarComponent } from 'ngx-simplebar';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
// import { NgxSimplebarComponent } from 'ngx-simplebar';
import { NgxSimplebarModule } from 'ngx-simplebar';






@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    VerticalComponent,
    SidebarComponent,
    TopbarComponent,
    FooterComponent,
    RsidebarComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CarouselModule,
    BrowserAnimationsModule,
    TranslateModule,
    NgxSimplebarModule,
    TranslateModule.forRoot(),
    BsDropdownModule.forRoot(),
    HttpClientModule

    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
