import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  apiUrl = 'http://localhost:4002/api/admin';

  constructor(private http: HttpClient) { }

  addPost(post: any): Observable<any> {
    console.log('${this.apiUrl}');
    return this.http.post<any>(`${this.apiUrl}/loginCheck`, post);

  }
}
