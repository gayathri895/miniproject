import { Injectable, WritableSignal, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  arf: any;
  
  static authenticated(arf: any): boolean | WritableSignal<boolean> {
   
    console.log(arf);
    
    if (arf=='2') {
      console.log("g");
      return false;
    } 
    if (arf=='0') {
      console.log("gfg");
      }
      return false;
   

    // if(arf == true || arf == ''){
    //   console.log("g");
    //   return true;
    // } else{
    //   console.log("gfg");
    // }
    // Default return statement if none of the conditions is met
   
  }
}