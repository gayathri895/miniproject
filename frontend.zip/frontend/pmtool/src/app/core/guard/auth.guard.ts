import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { inject } from '@angular/core';

// export const authGuard: CanActivateFn = (route, state) => {
//   return true;
// };

export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot,
  
) => {
  
var arf;
  // console.log('guard status: ', inject(TokenService).authenticated());

  return AuthService.authenticated('0')
    ? true
    : inject(Router).createUrlTree(['/account/login']);
};
