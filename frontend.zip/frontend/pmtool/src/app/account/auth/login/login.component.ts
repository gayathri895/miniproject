import { Component, signal } from '@angular/core';
// import { UntypedFormGroup } from '@angular/forms';
import { FormGroup, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { ApiserviceService } from 'src/app/core/service/apiservice.service';
import { AuthService } from 'src/app/core/service/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  constructor(private formBuilder: UntypedFormBuilder, private route: ActivatedRoute, private router: Router,private apiService: ApiserviceService,private authservice:AuthService) { }

  // loginform!:FormGroup;
    
  loginForm!: FormGroup;
  submitted:any = false;
  error:any = '';
  // returnUrl: string;

  carouselOption: OwlOptions = {
    items: 1,
    loop: false,
    margin: 0,
    nav: false,
    dots: true,
    responsive: {
      680: {
        items: 1
      },
    }
  }
  // formBuilder: any;

  
  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      // email: ['admin@themesbrand.com', [Validators.required]],
      password: ['', [Validators.required]],
    });
    // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
   var obj={
    email:this.f['email'].value,
    password:this.f['password'].value

    };
    if (this.loginForm.invalid) {
      return;
    }else{
      this.apiService.addPost(obj).subscribe((data) => {
       
        if(data.status=='1'){
          console.log("hi");
          AuthService.authenticated("2");
          this.router.navigate(['/dashboard/fdashboard']);
        }else{

        }

        // this.posts = data;
      });
      // console.log(obj);


    }

    



  }

}
