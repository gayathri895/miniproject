const adminmodel = require("../model/admin.model.js");
const moment = require("moment");


// const moment = require("moment");

// admin login start
exports.loginCheck = (req, res) => {
  console.log("hi");
  if (Object.keys(req.body).length === 0 || Object.keys(req.body).length != '2') {
    res.json({
      status: 0,
      message: "Content can not be empty!",
    });
  } else if (req.body.email == "" || req.body.password == "") {
    res.json({
      status: 0,
      message: "Field can not be empty!",
    });
  } else {
    const authCheck = new adminmodel({
      email: req.body.email,
      password: req.body.password,
    });

    console.log(authCheck);
    adminmodel.logincheck(authCheck, (err, data) => {
      if (err) {
        res.json({ status: "0", message: "Error While gettting data" });
      } else if (data["sts"] == "0") {
        res.json({ status: "0", message: "No User found" });
      } else if (data["sts"] == "1") {
        res.json({ status: "1", message: "Login Success, User found" });
      } else {
        res.json({ status: "0", message: "response failure" });
      }
    })
  }
}
// admin login end



