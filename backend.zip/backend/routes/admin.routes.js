
module.exports = app => {

    var router = require("express").Router();

    const admincontroller = require("../controller/admin.controller.js");

    router.post("/loginCheck", admincontroller.loginCheck);
  
    app.use('/api/admin', router);


};