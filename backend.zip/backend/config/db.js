var mysql = require('mysql');  
var con = mysql.createConnection({  
  host: "localhost",  
  user: "root",  
  password: "" ,
  database: 'pmtool',
});  

con.connect(err => {
  if (err) {
    console.error('connection error', err.stack)
  } else {
    console.log('Connected Sleep Me DB')
  }
})



module.exports = con;