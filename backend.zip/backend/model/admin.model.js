const DB = require("../config/db.js");
const moment = require("moment");
const authModel = function(authmodel) {
    this.email = authmodel.email;
    this.password = authmodel.password;
    
}








authModel.logincheck = (loginDetails, result) =>{
    var sqlQuery = `SELECT * from tbl_users where u_emailid = '${loginDetails.email}' and u_password = '${loginDetails.password}'`;
    
    DB.query(sqlQuery, (error, response) => {
        console.log(response);
        if (error) {
            var userres = {
                sts: "0",
                message: error
            }
            result(userres, null);
        } else if (response.length > 0) {
           
            var userres = {
                sts: "1",
                message: "User Found",
                result: response[0]
            }
            result(null, userres);
        } else {
            var userres = {
                sts: "0",
                message: "No user Found",
            }
            result(null, userres);
        }
    });
}


























  












 








  


module.exports = authModel;