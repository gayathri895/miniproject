const express = require("express");
const cors = require('cors');
const PORT = 4002;
const app = express();
const bodyParser = require('body-parser');
const http = require('http').Server(app);
const nocache = require('nocache');

app.use(cors());
app.use(nocache());

app.use('/assets', express.static('assets'));

app.get("/", (req, res) => {
    console.log(req.protocol);
    res.json({ message: "Sleep Me Application Node Api running Succesfully..." });
    res.end();
});
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

require("./routes/admin.routes.js")(app);

http.listen(PORT, function() {
    console.log('Sleep Me app is running on port 4002');
});